import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';

const dataFetcher = {
  courseList: '',
  courseNames: {},
  userData: {},
  data: {},

  // Fetch the user's course data
  getCourseData: async (accessToken) => {
    try {
      console.log('Fetching course data...');
      const response = await axios.get(`https://osu.instructure.com/api/v1/courses`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      dataFetcher.courseNames = response.data.reduce((acc, course) => {
        acc[course.id] = course.course_code;
        return acc;
      }, {});
      console.log('Courses fetched:', dataFetcher.courseNames);
    } catch (error) {
      console.error('Error fetching course data:', error);
    }
  },

  // Fetch assignments based on the course list
  updateAssignmentData: async (accessToken) => {
    try {
      console.log('Fetching assignment data...');
      const response = await axios.get(`https://osu.instructure.com/api/v1/calendar_events?type=assignment`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      dataFetcher.data.assignments = response.data;
      console.log('Assignments fetched:', dataFetcher.data.assignments);
      return dataFetcher.data.assignments;
    } catch (error) {
      console.error('Error fetching assignment data:', error);
    }
  },
};

const Popup = () => {
  const [accessToken, setAccessToken] = useState('');
  const [authStatus, setAuthStatus] = useState('Not Authenticated');
  const [assignments, setAssignments] = useState([]);

  const hardcodedAccessToken = '8597~aChk3ynkKfWfPcTtkL2rE2RVYKRRCzvXhhNy8r6m3VP6tJCVnaLt4PH6D4uR4Q9V';

  // Log hostname on component mount
  useEffect(() => {
    console.log('Popup component mounted');
    const rootElement = document.getElementById('root');
    console.log('Hostname:', location.hostname);
  }, []);

  // Handle input changes for the access token
  const handleInputChange = (e) => {
    setAccessToken(e.target.value);
  };

  // Directly handle the button click using native JS and then call the React function for fetching assignments
  useEffect(() => {
    const button = document.querySelector('button');
    if (button) {
      button.addEventListener('click', () => {
        console.log('Pure JS button click');

        // Trigger fetch assignments
        fetchAssignments();
      });
    }
  }, []);

  // Fetch the assignments when the user clicks the "Fetch Assignments" button
  const fetchAssignments = async () => {
    console.log('Fetch button clicked');
  
    const accessToken = hardcodedAccessToken; // Using hardcoded access token for testing
  
    if (!accessToken) {
      console.error('No access token provided');
      return;
    }
  
    chrome.runtime.sendMessage({ action: 'fetchData', accessToken: accessToken }, (response) => {
      if (response.success) {
        console.log("Courses fetched:", response.data);
        setAssignments(response.data);
      } else {
        console.error("Error fetching data:", response.error);
      }
    });
  };
  

  return (
    <div>
      <h1>Canvas Pet</h1>
      <p>Status: {authStatus}</p>

      {/* Input for the user to add their access token */}
      <input
        type="text"
        placeholder="Enter Canvas Access Token"
        value={accessToken}
        onChange={handleInputChange}
        style={{ width: '100%', padding: '10px', marginBottom: '10px' }}
      />

      {/* Button to fetch assignments */}
      <button 
        style={{ padding: '10px', width: '100%' }}>
        Fetch Assignments
      </button>

      {/* Display list of assignments */}
      <ul style={{ marginTop: '20px' }}>
        {assignments && assignments.length > 0 ? (
          assignments.map((assignment) => (
            <li key={assignment.id}>{assignment.title}</li>
          ))
        ) : (
          <li>No assignments available</li>
        )}
      </ul>
    </div>
  );
};

ReactDOM.render(<Popup />, document.getElementById('root'));

export default Popup;
