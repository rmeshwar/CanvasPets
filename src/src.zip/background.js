chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "fetchData") {
      const accessToken = message.accessToken;
  
      // Fetch course data from the Canvas API
      fetch(`https://osu.instructure.com/api/v1/courses`, {
        headers: {
          Authorization: `Bearer ${accessToken}`
        }
      })
        .then(response => response.json())
        .then(data => {
          sendResponse({ success: true, data: data });
        })
        .catch(error => {
          console.error("Error fetching courses:", error);
          sendResponse({ success: false, error: error });
        });
  
      // Ensure the function returns true to indicate that the response will be async
      return true;
    }
  });
  